<?php
// Fetching Values From URL

	$id2 = $_POST['id1'];
	$pwd2 = $_POST['pwd1'];
	$name2 = $_POST['name1'];
	$bio2 = $_POST['bio1'];
	$role2 = $_POST['role1'];
	$country2 = $_POST['country1'];
	
	$connection = mysql_connect("localhost", "root", "root12"); // Establishing Connection with Server
	$db = mysql_select_db("data", $connection); // Selecting Database,in may case 'data' is the name of the database.

	if (isset($_POST['id1'])) {
	//Insert Query
	$query = mysql_query("insert into registration(userid,password,name,bio,role,country) values ('id2','$pwd2','$name2','$bio2','$role2','$country2')"); 
	echo "Form Submitted succesfully";
	//  To redirect form on a particular page
	header("Location:submition.html");//to success page
	}
	mysql_close($connection); // Connection Closed
?>
