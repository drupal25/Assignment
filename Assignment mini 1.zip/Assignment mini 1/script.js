function myFunction() {

	var id = document.getElementById("userid").value;
	var pwd = document.getElementById("pwd").value;
	var name = document.getElementById("name").value;
	var bio = document.getElementById("bio").value;
	var role = document.getElementById("role").value;
	var country = document.getElementById("country").value;
	
		// Returns successful data submission message when the entered information is stored in database.

	var dataString = 'id1=' + id + 'pwd1=' + pwd + '&name1=' + name + 'bio1=' + bio + 'role1='+role + 'country1=' + country;


	if (id == '' || pwd == '' || name == '' bio == '' role == '' ||country == '') {
	alert("Please Fill All Fields");
	} else {
	// AJAX code to submit form.
	$.ajax({
	type: "POST",
	url: "reg.php",
	data: dataString,
	cache: false,
	success: function(html) {
	alert(html);
	}
	});
	}
	return false;

}
