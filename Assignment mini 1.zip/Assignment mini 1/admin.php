<? php
	include_once('connection.php');
	$query='select * from registration';
	$result=mysql_query($query);
?>

<!DOCTYPE html>
<html>
<title>
	<head>Read Data From Database Using PHP</head>
</title>

<body>
	<table align="center" border="1px" style="width:600px; line-height:40px;">
		<tr>
			<th colspan="8"><h2>REGISTERED FORMS</h2></th>
		</tr>
		<t>
			<th> USER ID </th>
			<th> PASSWORD </th>
			<th> NAME </th>
			<th> BIO </th>
			<th> ROLE </th>
			<th> COUNTRY </th>
			<th> UPDATE OPTION </th>
			<th> DELETE OPTION </th>
		</t>
		<?php 
		while($rows=mysql_fetch_assoc($result))
		{
		?>
		
		<tr>
			<td><?php echo $rows['userid']; ?></td>
			<td><?php echo $rows['password']; ?></td>
			<td><?php echo $rows['name']; ?></td>
			<td><?php echo $rows['bio']; ?></td>
			<td><?php echo $rows['role']; ?></td>
			<td><?php echo $rows['country']; ?></td>
			<td>
				<form action="update.php">
					<input id="update" name="update" type="submit" value="UPDATE">
				</form>
			</td>
			
			<td>
				<form action="delete.php">
					<input id="delete" name="delete" type="submit" value="DELETE">
				</form>
			</td>			
		</tr>
		
		<?php
			}
		?>
	</table>
</body>
</html>
		