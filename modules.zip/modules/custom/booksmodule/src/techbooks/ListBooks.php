<?php
namespace Drupal\booksmodule\techbooks;
use Drupal\Core\Controller\ControllerBase;
/**
 * Class ListBooks.
 *
 * @package Drupal\techbooks
 */
class ListBooks extends ControllerBase{
  public function getBooks() {
    return t('All your books will be listed!');
  }
}
?>