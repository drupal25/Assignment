<?php

namespace Drupal\pdf_drupal\Services;
use Drupal\Core\Session\AccountProxy;
use Drupal\user\Entity\User;
use Drupal\Core\Database\Connection;

libraries_load('fpdf');
/**
 * PdfService is a Drupal8 Service
 */
class PdfService {
	
	public function _populate_markup() {
		$user = User::load(\Drupal::currentUser()->id());
		
		//$connection = \Drupal::database();
		//$name = $connection->query("SELECT field_name FROM {EMPLOYEE} WHERE uid = '%s'", [ $data->uid ]);
		//$empno = $connection->query("SELECT field_employee_no FROM {EMPLOYEE} WHERE uid = '%s'", [ $data->uid ]);
		//$hra = $connection->query("SELECT field_h FROM {EMPLOYEE} WHERE uid = '%s'", [ $data->uid ]);
		//$basic = $connection->query("SELECT field_b FROM {EMPLOYEE} WHERE uid = '%s'", [ $data->uid ]);
		//$medical = $connection->query("SELECT field_m FROM {EMPLOYEE} WHERE uid = '%s'", [ $data->uid ]);
		//$protax = $connection->query("SELECT field_p FROM {EMPLOYEE} WHERE uid = '%s'", [ $data->uid ]);
		//$totsal = $connection->query("SELECT field_t FROM {EMPLOYEE} WHERE uid = '%s'", [ $data->uid ]);		
		
		if ($user->get('uid')->value < 1) {
		return t(' WARNNING !!! PLEASE LOG IN WITH YOUR ACCOUNT TO KNOW YOUR EMPLOYEE DETAILS ' );
		} else {
		$user_information  = 'User Name: ' . $user->getUsername() . "<br/>";
		$user_information .= 'Language: ' . $user->getPreferredLangcode() . "<br/>";
		$user_information .= 'Email: ' . $user->getEmail() . "<br/>";
		$user_information .= 'Timezone: ' . $user->getTimeZone() . "<br/>";
		$user_information .= 'Created: ' . date('m-d-Y h:i:s', $user->getCreatedTime()) . "<br/>";
		$user_information .= 'Updated: ' . date('m-d-Y h:i:s', $user->getChangedTime()) . "<br/>";
		$user_information .= 'Last Login: ' . date('m-d-Y h:i:s', $user->getLastLoginTime()) . "<br/>";
		//$user_information  = 'Name: ' . $name. "<br/>";
		//$user_information  = 'Employee number: ' . $empno. "<br/>";
		//$user_information  = 'HRA: ' . $hra. "<br/>";
		//$user_information  = 'Basic Salary: ' . $basic. "<br/>";
		//$user_information  = 'Medical Allowance: ' . $medical. "<br/>";
		//$user_information  = 'Professional Tax: ' . $protax. "<br/>";
		//$user_information  = 'Total Salary: ' . $totsal. "<br/>";
		$roles = NULL;
		foreach($user->getRoles() as $role) {
		$roles .= $role . ",";
		}
		$roles = 'Roles: ' . rtrim($roles, ',');
		$user_information .= $roles;
		
		return $user_information;
		}
	}
	
	public function generate_pdf(){
		$pdf = new FPDF();
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->Cell(40,10,_populate_markup().user_information);
		$pdf->Output();
	}
	
	
  
    /**
     * pdf function
     */
    public function pdfunc() {
		global $user;
        return $this->empno[array_rand($this->empno)]; 
    }
	
}