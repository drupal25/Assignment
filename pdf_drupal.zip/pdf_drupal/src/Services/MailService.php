<?php
namespace Drupal\pdf_drupal\Services;

use Drupal\Core\Session\AccountProxy;
use Drupal\user\Entity\User;
use Drupal\Core\Mail\MailManagerInterface;

/**
 * MailService is a Drupal8 Service for Auto Mailing
 */
class MailService {
	protected $mailManager;
	
	
	/**
	* 
	* 
	*/
	public function sendAutoMail($key, $to, $from, $data){
	  $mailManager = \Drupal::service('plugin.manager.mail');
	  $result = $this->mailManager->mail('pdf_drupal', $key, $to, $langcode, $params, NULL, $send_now);
	}
	
	/**
     * mail function
     */
	public function send_auto_mail() {
		$mailManager = \Drupal::service('plugin.manager.mail');
		
		$user = User::load(\Drupal::currentUser()->id());
		$to=$user->getEmail();
		$langcode = \Drupal::currentUser()->getPreferredLangcode();
		
	//Attaching a file to the email
    $attachment   = [
		//	For Static File i.e The file already present on hard drive
		//	'filecontent' => file_get_contents($file_uri),
		//	'filename' => 'data.pdf',
		//	'filemime' => 'pdf',
			
	//	For Dynamic File
       'uri' => $uri,
       'filename' => 'Request-' . $foundry_request->id() . '.pdf',
       'filemime' => 'application/pdf',
    ];
    $params['attachments'][] = (object) $attachment ;	
	
	$send_now = TRUE;
    // Send the mail, and check for success. Note that this does not guarantee
    // message delivery; only that there were no PHP-related issues encountered
    // while sending.
    $result = $this->mailManager->mail('pdf_drupal', 'key ?', $to, $langcode, $params, NULL, $send_now);
    if ($result['result'] == TRUE) {
      $this->messenger()->addMessage($this->t('Your Mail has been sent.'));
    }
    else {
      $this->messenger()->addMessage($this->t('There was a problem sending your Mail and it was not sent.'), 'error');
    }
		
	// $mailManager->mail('system', 'mail', $to, $langcode, $params);
}