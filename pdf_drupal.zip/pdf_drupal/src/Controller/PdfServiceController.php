<?php

namespace Drupal\pdf_drupal\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\pdf_drupal\Services\PdfService;
//use Drupal\modules\fpdf_custom_module\FPDF;

//module_load_include('php', 'volunteer',  'modules\fpdf_custom_module\fpdf');
class PdfServiceController extends ControllerBase {

	protected $pdf_service;
	
	public function __construct(PdfService $pdf_service) {
        $this->pdf_service = $pdf_service;
	}
	
	
	public static function create(ContainerInterface $container){
		return new static(
			$container->get('pdf_service.demo')
		);
	}
	
	/**
   * Display the markup.
   *
   * @return array
   *   Return markup array.
   */
	public function demo() {		
		return ['#markup' =>$this->pdf_service->_populate_markup()];
	}
	
	public function pdfgen() {		

		return ['#markup' =>$this->pdf_service->_populate_markup()];
	}
	
	public function automail() {		

		return ['#markup' =>$this->pdf_service->send_auto_mail()];
	}
}