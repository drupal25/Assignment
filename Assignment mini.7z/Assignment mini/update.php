<? php
	include_once('connection.php');
	$query='select * from registration';
	$result=mysql_query($query);
?>

<!DOCTYPE html>
<html>
   
   <head>
      <title>UPDATED RECORDS IN DATABASE AFTER UPDATETION OF RECORD</title>
   </head>
   
   <body>
      <?php
         if(isset($_POST['update'])) {
            $dbhost = 'localhost';
            $dbuser = 'root';
            $dbpass = 'root12';
            $conn = mysql_connect($dbhost, $dbuser, $dbpass);
            
            if(! $conn ) {
               die('Could not connect: ' . mysql_error());
            }
				
            
			
			$userid = $_POST['userid'];
            $password = $_POST['password'];
            $name = $_POST['name'];
			$bio = $_POST['bio'];
			$role = $_POST['role'];
			$country = $_POST['country'];
			
            $sql = "UPDATE registration ". "SET password = $password " ."SET name = $name " ."SET bio = $bio " .
										"SET role = $role " ."SET country = $country " .
					"WHERE userid = $userid" ;
			
			
			
            mysql_select_db('data');
            $retval = mysql_query( $sql, $conn );
            
            if(! $retval ) {
               die('Could not update data: ' . mysql_error());
            }
            echo "Updated data successfully\n";
            
            mysql_close($conn);
         }  ?>
		
			<table align="center" border="1px" style="width:600px; line-height:40px;">
		<tr>
			<th colspan="8"><h2>REGISTERED FORMS</h2></th>
		</tr>
		<t>
			<th> USER ID </th>
			<th> PASSWORD </th>
			<th> NAME </th>
			<th> BIO </th>
			<th> ROLE </th>
			<th> COUNTRY </th>
			<th> UPDATE OPTION </th>
			<th> DELETE OPTION </th>
		</t>
		<?php 
		while($rows=mysql_fetch_assoc($result))
		{
		?>
		
		<tr>
			<td><?php echo $rows['userid']; ?></td>
			<td><?php echo $rows['password']; ?></td>
			<td><?php echo $rows['name']; ?></td>
			<td><?php echo $rows['bio']; ?></td>
			<td><?php echo $rows['role']; ?></td>
			<td><?php echo $rows['country']; ?></td>
			<td>
				<form action="update.php">
					<input id="update" name="update" type="submit" value="UPDATE">
				</form>
			</td>
			
			<td>
				<form action="delete.php">
					<input id="delete" name="delete" type="submit" value="DELETE">
				</form>
			</td>			
		</tr>
		
		<?php
			}
		?>
	</table>
</body>
</html>