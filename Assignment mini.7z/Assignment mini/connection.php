<? php
	mysql_connect('localhost','root','root12');
	mysql_select_db('data');
?>
