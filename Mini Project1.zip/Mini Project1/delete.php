<!DOCTYPE html>
<html>
   <head>
      <title>UPDATED RECORDS IN DATABASE AFTER DELETION OF RECORD</title>
   </head>
   
   <body>
      <?php
         if(isset($_POST['delete'])) {
            $con=mysqli_connect("localhost","root","","data");
		// Check connection
			if (mysqli_connect_errno())
			{
				echo "Failed to connect to MySQL: " . mysqli_connect_error();
			}
            $userid =$_POST['userid'];
            $sql = "DELETE FROM registration WHERE userid = $userid" ;
            $del =mysqli_query($con,$sql);
            if(! $del ) {
               die('Could not delete data: ' . mysqli_error());
            }
            
            echo "Deleted data successfully\n";
            
            mysqli_close($conn);
			header("Location:admin.php");
         }  ?>
		
		
</body>
</html>