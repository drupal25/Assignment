<!DOCTYPE html>
<html>
<title>
	<head>Read Data From Database Using PHP</head>
</title>

<body>
	<table align="center" border="1px" style="width:600px; line-height:40px;">
		<tr>
			<th colspan="8"><h2>REGISTERED FORMS</h2></th>
		</tr>
		<t>
			<th> USER ID </th>
			<th> PASSWORD </th>
			<th> NAME </th>
			<th> BIO </th>
			<th> ROLE </th>
			<th> COUNTRY </th>
			<th> UPDATE OPTION </th>
			<th> DELETE OPTION </th>
		</t>
	<?php 
	$con=mysqli_connect("localhost","root","","data");
		// Check connection
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}

	$sql='select * from registration';
	$result=mysqli_query($con,$sql);
		while($row=mysqli_fetch_assoc($result))
		{
		?>
		
		<tr>
			<td><?php echo $row['userid']; //userid should not be editable ?></td> 
			<td contenteditable='true'><?php echo $row['password']; ?></td>
			<td contenteditable='true'><?php echo $row['name']; ?></td>
			<td contenteditable='true'><?php echo $row['bio']; ?></td>
			<td contenteditable='true'><?php echo $row['role']; ?></td>
			<td contenteditable='true'><?php echo $row['country']; ?></td>
			<td>
				<form action="update.php">
					<input id="update" name="update" type="submit" value="UPDATE">
				</form>
			</td>
			
			<td>
				<form action="delete.php">
					<button name="delete" id="delete" type="submit" value="DELETE">DELETE</button>
				</form>
			</td>			
		</tr>
		
		<?php
			}
			mysqli_close($con);
		?>
	</table>
</body>
</html>
		