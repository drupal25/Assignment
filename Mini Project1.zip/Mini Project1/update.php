<!DOCTYPE html>
<html>
   
   <head>
      <title>UPDATED RECORDS IN DATABASE AFTER UPDATETION OF RECORD</title>
   </head>
   
   <body>
      
		
			<table align="center" border="1px" style="width:600px; line-height:40px;">
		<tr>
			<th colspan="8"><h2>REGISTERED FORMS</h2></th>
		</tr>
		<tr>
			<th> USER ID </th>
			<th> PASSWORD </th>
			<th> NAME </th>
			<th> BIO </th>
			<th> ROLE </th>
			<th> COUNTRY </th>
			<th> UPDATE OPTION </th>
			<th> DELETE OPTION </th>
		</tr>
	<?php 
		if(isset($_POST['update'])) {
           
	   $con=mysqli_connect("localhost","root","","data");
		// Check connection
			if (mysqli_connect_errno())
			{
				echo "Failed to connect to MySQL: " . mysqli_connect_error();
			}
			
			$userid = $_POST['userid'];
            $password = $_POST['password'];
            $name = $_POST['name'];
			$bio = $_POST['bio'];
			$role = $_POST['role'];
			$country = $_POST['country'];
			
            $sql="UPDATE registration ". "SET password = $password " ."SET name = $name " ."SET bio = $bio " .
										"SET role = $role " ."SET country = $country " .
					"WHERE userid = $userid" ;

            $retval =mysqli_query($con,$sql);
            
            if(! $retval ) {
               die('Could not update data: ' . mysql_error());
            }
            echo "Updated data successfully\n";
    
		while($row=mysqli_fetch_assoc($retval))
		{
		?>
		
		<tr>
			<td><?php echo $row['userid']; ?></td>
			<td><?php echo $row['password']; ?></td>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['bio']; ?></td>
			<td><?php echo $row['role']; ?></td>
			<td><?php echo $row['country']; ?></td>
			<td>
				<form action="update.php">
					<input id="update" name="update" type="submit" value="UPDATE">
				</form>
			</td>
			
			<td>
				<form action="delete.php">
					<input id="delete" name="delete" type="submit" value="DELETE">
				</form>
			</td>			
		</tr>
		
		<?php
			}
		}
	?>
	</table>
</body>
</html>