<?php
// Fetching Values From URL

	$id2 = $_POST['id1'];
	$pwd2 = $_POST['pwd1'];
	$name2 = $_POST['name1'];
	$bio2 = $_POST['bio1'];
	$role2 = $_POST['role1'];
	$country2 = $_POST['country1'];
// Establishing Connection with Server
	$con=mysqli_connect("localhost","root","","data");
// Check connection
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	} 
	
	if (isset($_POST['id1'])) {
	//Insert Query
	$sql = mysqli_query($con,"insert into registration(userid,password,name,bio,role,country) values ('id2','$pwd2','$name2','$bio2','$role2','$country2')"); 
	echo "Form Submitted succesfully";
	//  To redirect form on a particular page
	header("Location:submition.html");//to success page
	}
	mysqli_close($con); // Connection Closed
?>
