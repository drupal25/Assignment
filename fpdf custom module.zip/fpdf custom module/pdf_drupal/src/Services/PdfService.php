<?php

namespace Drupal\pdf_drupal\Services;
use Drupal\Core\Session\AccountProxy;
use Drupal\user\Entity\User;
use Drupal\
//use Drupal\user\Entity\User;
/**
 * PdfService is a Drupal8 Service
 */
class PdfService {
	
	public function build() {
		return array(
		'#markup' => $this->_populate_markup(),
		);
	}

	private function _populate_markup() {
		$user = User::load(\Drupal::currentUser()->id());
		if ($user->get('uid')->value < 1) {
		return t(' WARNNING !!! PLEASE LOG IN WITH YOUR ACCOUNT TO KNOW YOUR EMPLOYEE DETAILS ' ));
		} else {
		$user_information  = 'User Name: ' . $user->getUsername() . "<br/>";
		$user_information .= 'Language: ' . $user->getPreferredLangcode() . "<br/>";
		$user_information .= 'Email: ' . $user->getEmail() . "<br/>";
		$user_information .= 'Timezone: ' . $user->getTimeZone() . "<br/>";
		$user_information .= 'Created: ' . date('m-d-Y h:i:s', $user->getCreatedTime()) . "<br/>";
		$user_information .= 'Updated: ' . date('m-d-Y h:i:s', $user->getChangedTime()) . "<br/>";
		$user_information .= 'Last Login: ' . date('m-d-Y h:i:s', $user->getLastLoginTime()) . "<br/>";
		$roles = NULL;
		foreach($user->getRoles() as $role) {
		$roles .= $role . ",";
		}
		$roles = 'Roles: ' . rtrim($roles, ',');
		$user_information .= $roles;
		
		return $user_information;
		}
	}
	
	public function generate_pdf(){
		$pdf = new FPDF();
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->Cell(40,10,_populate_markup().user_information);
		$pdf->Output();
	}
	
	
  
    /**
     * pdf function
     */
    public function pdfunc() {
		global $user;
        return $this->empno[array_rand($this->empno)]; 
    }
}









		//public $empno=$entity->field_employee_no->value;
		//public $name=$entity->field_name->value;
		//public $hra=$entity->field_h->value;
		//public $basic=$entity->field_b->value;
		//public $medical=$entity->field_m->value;
		//public $protax=$entity->field_p->value;
		//public $totsal=$entity->field_t->value;  