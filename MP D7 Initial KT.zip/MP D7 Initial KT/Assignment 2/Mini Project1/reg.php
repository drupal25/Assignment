<?php
// Establishing Connection with Server
	$con=mysqli_connect("localhost","root","","data");
// Check connection
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	} 
	
// Fetching Values From FORM
	
	$id2 = $_POST['userid'];
	$pwd2 = $_POST['pwd'];
	$name2 = $_POST['name'];
	$bio2 = $_POST['bio'];
	$role2 = $_POST['role'];
	$country2 = $_POST['country'];
	
	//Insert Query
	$sql = "insert into registration(userid,password,name,bio,role,country) 
					values ('$id2','$pwd2','$name2','$bio2','$role2','$country2')"; 
	
	if ($con->query($sql) === TRUE) {
    echo "New record created successfully";
	//  To redirect form on a particular page
	header("Location:submition.html");//to success page
	} else {
    echo "Error: " . $sql . "<br>" . $con->error;
	}
	
	
	mysqli_close($con); // Connection Closed
?>
