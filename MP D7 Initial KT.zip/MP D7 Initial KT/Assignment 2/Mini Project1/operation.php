<?php
$servername="localhost";
$username="root";
$password="";
$dbname="data";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userid1=$_POST['userid'];
$password1=$_POST['password'];
$name1=$_POST['name'];
$country1=$_POST['country'];
$bio1=$_POST['bio'];
$role1=$_POST['role'];


 
if($_POST['update']){
$sql = "update registration set password='$password1',name='$name1',bio='$bio1',role='$role1',country='$country1' where userid='$userid1';";
if ($conn->query($sql) === TRUE) 
	{ 
	header("Location:admin.php");	  
	} 
}
if($_POST['delete']){
$sql = "delete FROM registration where userid='$userid1';";
if ($conn->query($sql) === TRUE) 
	{ 
	header("Location:admin.php");
	} 
}


mysqli_close($conn);
?> 