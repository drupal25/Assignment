<!DOCTYPE html>
<html>
<title>
	<head>Read Data From Database Using PHP</head>
</title>

<body>
	<?php 
	$con=mysqli_connect("localhost","root","","data");
		// Check connection
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}

	$sql='select * from registration';
	$result=mysqli_query($con,$sql);
		while($row = mysqli_fetch_assoc($result)) {
		
        echo  "<form method='post' action='operation.php'>
				<center>
				<table border='1'>
				<tr><th>USER ID</th><th>PASSWORD</th><th>NAME</th><th>BIO</th><th>ROLE</th><th>COUNTRY</th><th colspan='2'>ACTION</th> </tr>
				<tr><td><input type='text' name='userid' value=".$row['userid']." readonly/></td>
				<td><input type='text' name='password' value=".$row['password']."></td>
				<td><input type='text' name='name' value=".$row['name']."></td>
				<td><input type='text' name='bio' value=".$row['bio']."></td>
				
				<td><select name='role'>
				<option value=".$row['role'].">".$row['role']."</option>
				<option value='admin'>admin</option>
				<option value='others'>others</option></select></td>
				
				<td><select name='country'>
				<option value=".$row['country'].">".$row['country']."</option>
				<option value='india'>India</option>
				<option value='usa'>USA</option>
				<option value='nepal'>Nepal</option>
				<option value='uk'>UK</option></select></td>
				
				
				<td><input type='submit' name='update' value='update'/></td>
				<td><input type='submit' name='delete' value='delete'/></td>
				</tr></table><br>
				</center>
				</form></body>" ;
				
    }
		//mysqli_close($con);
	?>
</body>
</html>
		