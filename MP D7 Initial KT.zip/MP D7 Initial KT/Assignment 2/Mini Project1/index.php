<html>
<body>

<?php
 if($_SERVER['REQUEST_METHOD'] == 'POST')
    {
    $userid = $_POST['userid'];
    $pwd = $_POST['pwd'];
	$usertype = $_POST['usertype'];
	
    $userid = htmlspecialchars($userid);
    $pwd = htmlspecialchars($pwd);
	$usertype = htmlspecialchars($usertype);
	
    $user = "root";
    $pass = "";
    $database = "data";
	
    $link =mysqli_connect( "localhost", $user, $pass,$database ); //new PDO("mysql:host='localhost';dbname=$database", $user, $pass);
  
		if(!$link)
		{
		    die ( "Could not connect to MySQL : " .mysql_error() );
		}
		 mysqli_select_db($link,$database) or die ( "Could not select MySQL $database : " .mysql_error() );
	
    $result = mysqli_query($link, "SELECT * FROM registration WHERE userid = '$userid' AND password = '$pwd' AND role='$usertype'" );
	//registration is table name in data base 
	while($row =mysqli_fetch_array($result))
    {
    if($row["userid"] == $userid && $row["password"] == $pwd && $row["role"]=="admin")
	{
		//  To redirect form on admin page
		header("Location:admin.php");
	}
	else if($row["userid"] == $userid && $row["password"] == $pwd && $row["role"]=="others")
	{
		//  To redirect form on home page
		header("Location:Home.html");
	}
    else
    {
    echo "Username and Password does not match";
    }
    }
    }
?>

</body>
</html>