<?php
// Establishing Connection with Server
	$con=mysqli_connect("localhost","root","","data");
// Check connection
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	} 
// Telling from which table the data is to be extracted
	$tableName  = 'registration';
// Telling to which file the data of table is to be stored
	$backupFile = 'C:\wamp64\www\export_sql\storing_file.txt';
// SQL Query for extracting data from the given table and saving it to the given file
	$sql = "SELECT * FROM registration INTO OUTFILE 'storing_file.txt'";

	if ($con->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $con->error;
	}
	
	
	mysqli_close($con); // Connection Closed
	
// SELECT * FROM registration INTO OUTFILE 'C:/wamp64/www/export_sql/storing_file.txt'
?>